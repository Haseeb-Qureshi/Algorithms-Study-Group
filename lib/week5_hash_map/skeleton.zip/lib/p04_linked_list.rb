Link = Struct.new(:key, :val, :next, :prev)

class LinkedList
  attr_reader :head

  def initialize
  end

  def insert(key, val)
  end

  def get(key)
  end

  def include?(key)
  end

  def remove(key)
  end

  def each
  end
end
